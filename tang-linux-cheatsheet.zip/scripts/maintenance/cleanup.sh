#!/bin/bash
echo "Cleaning logs & apt cache..."
sudo apt autoremove -y
sudo apt clean
sudo journalctl --vacuum-time=3d
echo "Done!"
