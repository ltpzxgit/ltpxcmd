#!/bin/bash
echo "===== System Info ====="
uname -a

echo
echo "===== Disk ====="
df -h

echo
echo "===== Memory ====="
free -h
