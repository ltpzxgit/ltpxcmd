#!/bin/bash
# Creates a compressed backup of /var/www/html
tar -czvf backup-$(date +%F).tar.gz /var/www/html
