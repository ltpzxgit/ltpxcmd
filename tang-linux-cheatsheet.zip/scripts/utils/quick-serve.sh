#!/bin/bash
echo "Serving current directory on port 8000"
python3 -m http.server 8000
