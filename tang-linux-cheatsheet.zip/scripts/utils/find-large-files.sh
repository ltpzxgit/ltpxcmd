#!/bin/bash
echo "Top 20 biggest files (might need sudo):"
sudo find / -type f -exec du -h {} + 2>/dev/null | sort -hr | head -20
