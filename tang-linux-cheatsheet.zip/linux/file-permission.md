# Linux File Permission

## View permissions
`ls -l`

## Change permissions
- `chmod 755 file.sh`
- `chown ubuntu:ubuntu file`

## Handy tricks
- `sudo !!` — run the last command with sudo
