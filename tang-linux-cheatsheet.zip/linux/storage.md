# Storage Commands

- `df -h` — check disk usage
- `du -sh *` — see folder sizes
- `mount`, `umount`
- `lsblk` — list block devices
