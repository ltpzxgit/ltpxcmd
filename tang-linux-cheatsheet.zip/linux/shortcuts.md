# Linux Shortcuts

- `Ctrl + C` — cancel current command
- `Ctrl + D` — logout / send EOF
- `Ctrl + R` — reverse search command history
