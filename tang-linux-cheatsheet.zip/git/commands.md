# Git Commands

- `git clone URL`
- `git status`
- `git add .`
- `git commit -m "msg"`
- `git push`
- `git pull`
- `git checkout -b feature/x`
- `git merge main`
