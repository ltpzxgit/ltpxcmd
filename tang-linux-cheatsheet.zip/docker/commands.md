# Docker Commands

- `docker ps -a`
- `docker images`
- `docker build -t app .`
- `docker run -d -p 80:80 app`
- `docker logs -f container`
- `docker exec -it container bash`
- `docker stop container`
- `docker rm container`
