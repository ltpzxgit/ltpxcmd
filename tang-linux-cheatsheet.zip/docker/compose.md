# Docker Compose

## Up / Down
- `docker compose up -d`
- `docker compose down`

## Rebuild
- `docker compose up --build -d`

## Logs
- `docker compose logs -f`
