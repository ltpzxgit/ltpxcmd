# tmux Cheat Sheet

- `tmux new -s session`
- `tmux ls`
- `tmux attach -t session`
- `Ctrl + B`, `%` — split vertical
- `Ctrl + B`, `"` — split horizontal
