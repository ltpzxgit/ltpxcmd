# SSH Basics

- `ssh user@host`
- `ssh -i key.pem user@host`
- `chmod 600 key.pem`
- `ssh-copy-id user@host`
